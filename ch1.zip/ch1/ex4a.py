# (Equation value) (y = ax^3 + bx^2 + cx + d)
a=float(input("enter a value"))
b=float(input("enter b value"))
c=float(input("enter c value"))
d=float(input("enter d value"))
x=float(input("enter x value"))
y = a*x**3 + b*x**2 + c*x + d
print("y",y)