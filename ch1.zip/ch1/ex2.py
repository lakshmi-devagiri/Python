# bank interest
# i = pnr/100
p = float(input("Enter the principal amount"))
n = int(input("Enter number of years"))
r = float(input("Enter the rate of interest per annum"))
i= p*n*r/100
print("interest = ",i)