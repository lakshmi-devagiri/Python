# (Equation value) (y = ax^3 + bx^2 + cx + d)
a=float(input("Enter a values:"))
b=float(input("Enter b values:"))
c=float(input("Enter c values:"))
d=float(input("Enter d values:"))
x=float(input("Enter x values:"))
y= a*x**3 + b*x**2 + c*x + d
print("y",y)

              