print("Lakshmi")
