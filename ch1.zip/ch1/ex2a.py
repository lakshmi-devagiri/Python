p = float(input("enter p value"))
n = float(input("enter n value"))
r = float(input("enter r value"))
i= p*n*r/100
print("interest=",i)